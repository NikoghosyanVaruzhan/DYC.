package com.example.dyc;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MapActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.page_2);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId()==R.id.page_1){
                    Intent intent=new Intent(MapActivity.this, ListActivity.class);
                    startActivity(intent);
                }
                if(menuItem.getItemId()==R.id.page_3){
                    Intent intent=new Intent(MapActivity.this, ProfileActivity.class);
                    startActivity(intent);
                }
                if(menuItem.getItemId()==R.id.page_4){
                    Intent intent=new Intent(MapActivity.this, AboutActivity.class);
                    startActivity(intent);
                }
                return false;
            }
        });
    }
}